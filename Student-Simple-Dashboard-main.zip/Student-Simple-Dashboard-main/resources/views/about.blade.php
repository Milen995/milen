@extends("layout.main")

@section("container")
<h1>Identity</h1>
<img widh ="800" src ="{{$foto}}"></img>
<p>nama : {{$nama}}</p>
<p>kelas : {{$kelas}}</p>
@endsection