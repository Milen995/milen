@extends("layout.main")
@section("container")
<h1>ini adalah {{$title}}</h1>
@endsection